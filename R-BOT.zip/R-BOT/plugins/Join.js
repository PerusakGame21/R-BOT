const { MessageType } = require('@adiwajshing/baileys')

let handler = async(m, { conn, text }) => {
    if (!text) return conn.reply(m.chat, 'Silahkan masukkan link grup nya', m)
    if (text > 300) return conn.reply(m.chat, 'Maaf link Terlalu Panjang, Maksimal 300 Teks', m)
    var nomor = m.sender
    const teks1 = `*[JOIN GRUP]*\nNomor : wa.me/${nomor.split("@s.whatsapp.net")[0]}\nLink : ${text}`
    conn.sendMessage('6281336286149@s.whatsapp.net', teks1, MessageType.text)
    conn.reply(m.chat, '✔️Link telah di Kirim ke owner BOT, Silahkan Bayar Dan Kirim Bukti Pembayaran Ke Owner.\nPembayar Bisa Via Dana/Pulsa/Gopay.', m)
}
handler.help = ['join <link grup>']
handler.tags = ['daftar']
handler.command = /^(join)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

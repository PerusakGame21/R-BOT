let axios = require("axios");
let handler = async(m, { conn, text }) => {

  await m.reply('Searching...')
	axios.get(`https://api.vhtear.com/cerita_sex&apikey=1BlnApiIkyPake`).then ((res) => {
	 	let hasil = `Judul :${res.data.result.judul}\nCerita :${res.data.result.cerita}`

    conn.reply(m.chat, hasil, m)
	})
}
handler.help = ['cersrx'].map(v => v + ' <nama>')
handler.tags = ['quotes']
handler.command = /^(cersex)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0
handler.limit = true

module.exports = handler
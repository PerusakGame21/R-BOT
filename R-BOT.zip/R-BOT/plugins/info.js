let handler  = async (m, { conn, usedPrefix: _p }) => {
let info = `
╭─「 INFO BOT 」
│
│> Bot Recoded By :
│• Ibnu NR
│> Owner By :
│• Riko
│
│> Bot Dibuat Dengan :
│• JavaScript via NodeJS
│• FFmpeg
│
│> Thanks To :
│• Nurutomo
│• Drawl Nag
│• Riko
│• Ibnu NR
│• Caliph
│• RC047
╰──────────────────
╭──°❀❬ *DONASI* ❭❀°──
│• *Telkomsel:* [0813-3628-6149]
│• *Gopay:* [0813-3628-6149]
│ 「 *Chat OWNER* 」
│ > *Ingin donasi? Wa.me/6281336286149*
╰────────────────
`.trim()

conn.fakeReply(m.chat, info, '0@s.whatsapp.net', '*BOT TERVERIFIKASI*', 'status@broadcast')
}
handler.help = ['info']
handler.tags = ['info']
handler.command = /^(info)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

module.exports = handler

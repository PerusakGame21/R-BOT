let handler = async m => m.reply(`
┏━━°❀❬ *TQTO DEV API* ❭❀°━━┓
┣➥ *Bany :* adadeh
┣➥ *Videfikri:* no apikey
┣➥ *Caliph:* FreeApi
┣➥ *Zeks:* apivinz
┣➥ *OnlyDevCity:* PunyaIkyAds
┃ 「 *Pesan Dari My Owner* 」
┃ > *Trimakasih Telah Membantu*
┃ *Jalanya Bot Ini :')*
┗━━━━━━━━━━━━━━━━
`.trim()) // Tambah sendiri kalo mau
handler.help = ['apikey']
handler.tags = ['info']
handler.command = /^apikey$/i
handler.rowner = true
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = false

module.exports = handler

let axios = require("axios");
let handler = async(m, { conn, text }) => {

    if (!text) return conn.reply(m.chat, 'Silahkan ketik apa yg mau kamu cari,contoh *!kusonime doraemon*', m)

  await m.reply('*[❗] WAIT, Tunggu Sebentar*\n*kalo gk menerima pesan itu tanda nya kamu salah kasih judul:v.*')
	axios.get(`https://recoders-area.herokuapp.com/api/manga?search=${text}&apikey=FreeApi`).then ((res) => {
	 	let hasil = `*Note :${res.data.result.note}*\n*Title :${res.data.result.title}*\n\n*Nama :${res.data.result.name}*\n*Type :${res.data.result.type}*\n*Pembuat :${res.data.result.author}*\n*Genre :${res.data.result.genre}*\n*Rating :${res.data.result.rating}*\n*Released : ${res.data.result.released}*Status :${res.data.result.status}*\n*Download :${res.data.result.downloads.date}*\n*Title :${res.data.result.downloads.title}*\n*Description :${res.data.result.description}*\n*Link : ${res.data.result.downloads.link}*`               

    conn.reply(m.chat, hasil, m)
	})
}
handler.help = ['manga'].map(v => v + ' <nama>')
handler.tags = ['quotes']
handler.command = /^(manga)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.exp = 0

module.exports = handler
let handler = async m => m.reply(`
┏━━°❀❬ *DONASI* ❭❀°━━┓
┣➥ *Indosat Ooredoo:* [0813-3628-6149]
┣➥ *3:* [0898-9031-500]
┣➥ *Gopay:* [0813-3628-6149]
┃ 「 *Chat OWNER* 」
┃ > *Ingin donasi? Wa.me/081336286149*
┗━━━━━━━━━━━━━━━━
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler

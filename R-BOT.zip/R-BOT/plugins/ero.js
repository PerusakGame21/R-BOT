let fetch = require('node-fetch')
let handler = async (m, { conn, args }) => {
   response = args.join(' ')
  if (!args) throw 'Masukkan Parameter'
  m.reply('Sedang Diproses...')
  let res = `https://api.xteam.xyz/randomimage/ero?apikey=MIMINETBOT`
  conn.sendFile(m.chat, res, 'ero.jpg', `wangy wangy wangy`, m, false)
}
handler.help = ['ero'].map(v => v + ' ')
handler.tags = ['image']

handler.command = /^(ero)$/i

module.exports = handler